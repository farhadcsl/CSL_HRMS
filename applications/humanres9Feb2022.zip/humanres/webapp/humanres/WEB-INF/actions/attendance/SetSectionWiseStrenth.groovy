 session.setAttribute("sectionWiseStrenthList", sectionWiseStrenthList);
 session.setAttribute("total", total);