 session.setAttribute("designationWiseLeaveList", designationWiseLeaveList);
  session.setAttribute("selectedDate", selectedDate);