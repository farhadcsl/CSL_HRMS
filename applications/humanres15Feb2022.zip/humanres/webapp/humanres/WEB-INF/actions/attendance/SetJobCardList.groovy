session.setAttribute("employeeLogList", employeeLogList);
session.setAttribute("summeryReport", summeryReport);
session.setAttribute("employmentInfo", employmentInfo);