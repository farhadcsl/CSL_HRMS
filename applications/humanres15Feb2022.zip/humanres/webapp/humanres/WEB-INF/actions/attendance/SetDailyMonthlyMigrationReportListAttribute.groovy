 session.setAttribute("dailyMonthlyMigrationList", dailyMonthlyMigrationList);

