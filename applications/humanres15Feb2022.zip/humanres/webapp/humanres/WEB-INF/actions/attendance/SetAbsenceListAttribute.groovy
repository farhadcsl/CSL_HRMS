 session.setAttribute("absenceList", absenceList);
 session.setAttribute("selectedDate", selectedDate);