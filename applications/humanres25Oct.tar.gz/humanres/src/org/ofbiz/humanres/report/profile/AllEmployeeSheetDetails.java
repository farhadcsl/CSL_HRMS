package org.ofbiz.humanres.report.profile;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRMapCollectionDataSource;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporterParameter;

import org.ofbiz.base.util.Debug;
import org.ofbiz.base.util.UtilHttp;
import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.base.util.cache.UtilCache;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.entity.condition.EntityCondition;
import org.ofbiz.entity.condition.EntityExpr;
import org.ofbiz.entity.condition.EntityOperator;
import org.ofbiz.service.DispatchContext;
import org.ofbiz.service.GenericDispatcher;
import org.ofbiz.webapp.control.ContextFilter;
import org.ofbiz.webapp.view.ViewHandlerException;

import javolution.util.FastList;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AllEmployeeSheetDetails {
	
	public static String generateReport(HttpServletRequest request, HttpServletResponse response) {

        Delegator delegator = (Delegator) request.getAttribute("delegator");
        Map<String, Object> ctx = UtilHttp.getParameterMap(request);
        JRDataSource jrDataSource = createReportDataSource(delegator, ctx);

    /*  String partyId = request.getParameter("partyId");*/

        HashMap jrParameters = new HashMap();
        
        /*jrParameters.put("employeeName", "1234");*/
      

        request.setAttribute("jrDataSource", jrDataSource);
        request.setAttribute("jrParameters", jrParameters);
        return "success";
    }
	 public static JRDataSource createReportDataSource(Delegator delegator, Map<String, Object> ctx) {
	        JRMapCollectionDataSource dataSource;
	        Collection reportRows = initializeMapCollection(delegator, ctx);
	        dataSource = new JRMapCollectionDataSource(reportRows);
	        return dataSource;
	    }
	 
	 private static Collection initializeMapCollection(Delegator delegator, Map<String, Object> ctx) {

		 List<GenericValue> employeeList = null;
		    GenericValue employee = null;
		    
		    List<EntityExpr> exprs = FastList.newInstance(); 
		    exprs.add(EntityCondition.makeCondition("employmentType", EntityOperator.NOT_EQUAL, null));
		    try {
		    	employeeList=delegator.findList("EmploymentAndPerson", EntityCondition.makeCondition(exprs, EntityOperator.AND), null, null, null, false);
		      } catch (GenericEntityException e) {
		        e.printStackTrace();
		    }
		   /* String partyId = (String) ctx.get("partyId");*/
		    ArrayList reportRows = new ArrayList();
		    HashMap rowMap = new HashMap();
		    assert employeeList != null;
		    
		    for (GenericValue employeeValue : employeeList) {

		    	rowMap = new HashMap();
		        String employeePartyId = null;
		        if (UtilValidate.isNotEmpty(employeeValue)) {
		            employeePartyId = employeeValue.getString("partyId");
		        }
		        
       String employeeName = SingleEmployeeProfileService.getAnEmployeeName(delegator, employeePartyId);
       String employeeId = SingleEmployeeProfileService.getAnEmployeeId(delegator, employeePartyId);
       String mobileno = SingleEmployeeProfileService.getAnEmployeeMobile(delegator, employeePartyId);
       String designation = SingleEmployeeProfileService.getAnEmployeeDesignation(delegator, employeePartyId);
       String bloodgroup = SingleEmployeeProfileService.getAnBloodGroup(delegator, employeePartyId);
       String department = SingleEmployeeProfileService.getAnDepartment(delegator, employeePartyId);
       String fatherName = SingleEmployeeProfileService.getAnFatherName(delegator, employeePartyId);
       String birthdate = SingleEmployeeProfileService.getAnDateofBirth(delegator, employeePartyId);
       String email = SingleEmployeeProfileService.getAnEmailAdress(delegator, employeePartyId);
       rowMap.put("employeeId", employeeId);
       rowMap.put("employeeName", employeeName);
       rowMap.put("mobileno", mobileno);
       rowMap.put("designation", designation);
       rowMap.put("bloodgroup", bloodgroup);
       rowMap.put("department", department);
       rowMap.put("fatherName", fatherName);
       rowMap.put("birthdate", birthdate);
       rowMap.put("email", email);
       reportRows.add(rowMap);
		    }
       return reportRows;
   }
}