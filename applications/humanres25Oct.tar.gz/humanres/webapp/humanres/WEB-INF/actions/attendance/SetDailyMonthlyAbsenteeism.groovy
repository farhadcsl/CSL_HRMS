 session.setAttribute("absenteeismList", absenteeismList);
 session.setAttribute("additionalInfo", additionalInfo);