/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
 
import org.ofbiz.entity.condition.*;
 
exprList = [EntityCondition.makeCondition("statusId", EntityOperator.NOT_EQUAL, "PARTY_DISABLED"), 
			EntityCondition.makeCondition("partyIdFrom", EntityOperator.EQUALS, context.companyName), 
            EntityCondition.makeCondition("statusId", EntityOperator.NOT_EQUAL, null)];
condList = EntityCondition.makeCondition(exprList, EntityOperator.AND);

exprList2 = [EntityCondition.makeCondition("statusId", EntityOperator.EQUALS, null),
			 EntityCondition.makeCondition("partyIdFrom", EntityOperator.EQUALS, context.companyName)];
CondList2 = EntityCondition.makeCondition(exprList2, EntityOperator.AND);

context.andCondition = EntityCondition.makeCondition([condList, CondList2], EntityOperator.OR);
 
