 session.setAttribute("manpowerList", manpowerList);
 session.setAttribute("finalRowList", finalRowList);